package com.vitalii.vorobii.runit.constant;

public interface Topics {
	String SUBMISSIONS = "submissions";
}
