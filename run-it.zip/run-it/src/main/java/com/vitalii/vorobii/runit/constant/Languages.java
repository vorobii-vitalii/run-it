package com.vitalii.vorobii.runit.constant;

public interface Languages {
	String JAVA = "java";
	String C = "c";
	String PYTHON = "python";
}
