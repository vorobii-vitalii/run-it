package com.vitalii.vorobii.runit.constant;

import java.util.Scanner;

public class Solution {

	public static void main(String[] args) {
		System.out.print("Hello");
	}
}
