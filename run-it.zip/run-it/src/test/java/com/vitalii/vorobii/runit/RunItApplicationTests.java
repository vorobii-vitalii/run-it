package com.vitalii.vorobii.runit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RunItApplicationTests {

	@Test
	void contextLoads() {
	}

}
